"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart3,
  PieChart,
  Users,
  Target,
  ArrowUpRight,
  ArrowDownRight,
  Info,
  Filter,
  Download,
  RefreshCw,
  Search,
  Plus,
  Settings,
  Edit,
  Trash2,
  ExternalLink,
  TrendingUp,
  Sparkles,
  BookOpen,
  Link,
} from "lucide-react"

export default function Dashboard() {
  const [currentPage, setCurrentPage] = useState("performance")
  const [selectedBrand, setSelectedBrand] = useState("jeep")
  const [dateRange, setDateRange] = useState("7days")

  const navigation = [
    { id: "performance", name: "Performance Summary", icon: BarChart3, active: true },
    { id: "mentioned-brands", name: "Mentioned Brands", icon: Target },
    { id: "prompt-library", name: "Prompt Library", icon: BookOpen },
    { id: "cited-sources", name: "Cited Sources", icon: Link },
    { id: "brands", name: "Brands", icon: Users },
  ]

  const awarenessData = {
    score: 52,
    change: -16,
    rank: 3,
    trend: "down",
  }

  const sovData = {
    score: 13,
    change: 4.1,
    trend: "up",
  }

  const competitors = [
    { name: "Bronco", score: 64, change: -9.7, rank: 1 },
    { name: "Toyota", score: 64, change: -28, rank: 2 },
    { name: "Land Rover", score: 24, change: -13, rank: 4 },
  ]

  const otherBrands = [
    { name: "Subaru", score: 24, change: -7.6 },
    { name: "Lexus", score: 20, change: -1.1 },
    { name: "Hyundai", score: 20, change: 9.5 },
    { name: "Honda", score: 20, change: -1.7 },
    { name: "GMC", score: 16, change: -2.1 },
  ]

  const heatmapData = {
    segments: [
      { brand: "Bronco", score: 64 },
      { brand: "Toyota", score: 64 },
      { brand: "Jeep", score: 52 },
      { brand: "Land Rover", score: 24 },
      { brand: "Subaru", score: 24 },
      { brand: "Lexus", score: 20 },
      { brand: "Hyundai", score: 20 },
      { brand: "Honda", score: 20 },
      { brand: "GMC", score: 16 },
      { brand: "Chevrolet", score: 16 },
    ],
    funnelStages: [
      { brand: "Bronco", top: 100, middle: 33, bottom: 73, overall: 100 },
      { brand: "Toyota", top: 100, middle: 44, bottom: 64, overall: 100 },
      { brand: "Jeep", top: 100, middle: 33, bottom: 55, overall: 67 },
      { brand: "Land Rover", top: 100, middle: 0, bottom: 36, overall: 0 },
      { brand: "Subaru", top: 50, middle: 22, bottom: 27, overall: 0 },
    ],
  }

  const prompts = [
    {
      id: 1,
      text: "I'm looking for a new vehicle that can handle both daily commuting and weekend camping trips...",
      brandMention: 88,
      segment: "Adventure",
      funnelStage: "Top",
      status: "active",
    },
    {
      id: 2,
      text: "What are the essential features to look for in a mid-size pickup truck if I plan to use it primarily...",
      brandMention: 13,
      segment: "Utility",
      funnelStage: "Middle",
      status: "active",
    },
    {
      id: 3,
      text: "How much does a reliable 4WD SUV cost for family use?",
      brandMention: 60,
      segment: "Family",
      funnelStage: "Bottom",
      status: "active",
    },
    {
      id: 4,
      text: "What are the best off-road SUVs for trail driving and outdoor adventures?",
      brandMention: 100,
      segment: "Adventure",
      funnelStage: "Middle",
      status: "active",
    },
  ]

  const citedSources = [
    {
      url: "https://www.americanfreight.net/blog/the-best-off-road-suvs-your-ultimate-guide-to-rugged-adventure",
      citations: 5,
      lastCited: "July 29, 2025",
      category: "none",
    },
    {
      url: "https://www.truecar.com/best-cars-trucks/suvs/four-wheel-drive/",
      citations: 5,
      lastCited: "July 29, 2025",
      category: "none",
    },
    {
      url: "https://www.jayhodgefordofmorrilton.com/guide-to-understanding-off-road-specs-morrilton-ar.html",
      citations: 2,
      lastCited: "July 29, 2025",
      category: "none",
    },
  ]

  const topDomains = [
    { domain: "youtube.com", percentage: 45 },
    { domain: "truecar.com", percentage: 38 },
    { domain: "quora.com", percentage: 32 },
    { domain: "edmunds.com", percentage: 28 },
    { domain: "kbb.com", percentage: 25 },
  ]

  const brands = [
    {
      name: "Honda",
      logo: "H",
      prompts: 6,
      competitors: 0,
      audits: 0,
      dailyRuns: true,
      color: "bg-slate-600",
    },
    {
      name: "Jeep",
      logo: "J",
      prompts: 9,
      competitors: 3,
      audits: 0,
      dailyRuns: true,
      color: "bg-slate-800",
    },
    {
      name: "RedShelf",
      logo: "R",
      prompts: 8,
      competitors: 0,
      audits: 0,
      dailyRuns: true,
      color: "bg-[#EB008B]",
    },
    {
      name: "Toyota",
      logo: "T",
      prompts: 2,
      competitors: 0,
      audits: 0,
      dailyRuns: true,
      color: "bg-red-600",
    },
  ]

  const renderPerformancePage = () => (
    <div className="space-y-8">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Awareness Score */}
        <Card className="bg-white border-slate-200 shadow-sm hover:shadow-md transition-all duration-200">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold text-slate-900 flex items-center">
                Awareness Score
                <Info className="w-4 h-4 ml-2 text-slate-400" />
              </CardTitle>
              <Badge variant="secondary" className="bg-slate-100 text-slate-700">
                Jeep
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center mb-6">
              <div className="relative w-48 h-48">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="40" stroke="#e2e8f0" strokeWidth="8" fill="none" />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="url(#awarenessGradient)"
                    strokeWidth="8"
                    fill="none"
                    strokeDasharray={`${awarenessData.score * 2.51} 251`}
                    strokeLinecap="round"
                    className="transition-all duration-1000 ease-out"
                  />
                  <defs>
                    <linearGradient id="awarenessGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#2D4964" />
                      <stop offset="100%" stopColor="#64EC29" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-slate-900">{awarenessData.score}%</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center">
                <ArrowDownRight className="w-4 h-4 text-[#EB008B] mr-1" />
                <span className="text-[#EB008B] font-medium">{awarenessData.change}%</span>
                <span className="text-slate-500 ml-1">since last week</span>
              </div>
              <div className="flex items-center">
                <span className="text-slate-500">Rank:</span>
                <span className="font-semibold text-slate-900 ml-1">#{awarenessData.rank}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SOV Score */}
        <Card className="bg-white border-slate-200 shadow-sm hover:shadow-md transition-all duration-200">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold text-slate-900 flex items-center">
                SOV (Share of Voice)
                <Info className="w-4 h-4 ml-2 text-slate-400" />
              </CardTitle>
              <Badge variant="secondary" className="bg-slate-100 text-slate-700">
                Jeep
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center mb-6">
              <div className="relative w-48 h-48">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="40" stroke="#e2e8f0" strokeWidth="8" fill="none" />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="url(#sovGradient)"
                    strokeWidth="8"
                    fill="none"
                    strokeDasharray={`${sovData.score * 2.51} 251`}
                    strokeLinecap="round"
                    className="transition-all duration-1000 ease-out"
                  />
                  <defs>
                    <linearGradient id="sovGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#318E99" />
                      <stop offset="100%" stopColor="#8BC53F" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-slate-900">{sovData.score}%</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center">
                <ArrowUpRight className="w-4 h-4 text-[#8BC53F] mr-1" />
                <span className="text-[#8BC53F] font-medium">+{sovData.change}%</span>
                <span className="text-slate-500 ml-1">since last week</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Competitor Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Awareness Score Competitors */}
        <Card className="bg-white border-slate-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">Named Competitors - Awareness</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {competitors.map((competitor, index) => (
                <div
                  key={competitor.name}
                  className="flex items-center justify-between p-4 bg-gradient-to-r from-slate-50 to-slate-100 rounded-xl hover:from-slate-100 hover:to-slate-200 transition-all duration-200"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-[#2D4964] text-white rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </div>
                    <span className="font-medium text-slate-900">{competitor.name}</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-32">
                      <Progress value={competitor.score} className="h-3" />
                    </div>
                    <span className="font-semibold text-slate-900 w-12 text-right">{competitor.score}%</span>
                    <div className="flex items-center w-20">
                      <ArrowDownRight className="w-4 h-4 text-[#EB008B] mr-1" />
                      <span className="text-[#EB008B] text-sm font-medium">{competitor.change}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Other Brands */}
        <Card className="bg-white border-slate-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">Other Brands - Awareness</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {otherBrands.map((brand, index) => (
                <div
                  key={brand.name}
                  className="flex items-center justify-between p-4 bg-gradient-to-r from-slate-50 to-slate-100 rounded-xl hover:from-slate-100 hover:to-slate-200 transition-all duration-200"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-slate-400 text-white rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 5}
                    </div>
                    <span className="font-medium text-slate-900">{brand.name}</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-32">
                      <Progress value={brand.score} className="h-3" />
                    </div>
                    <span className="font-semibold text-slate-900 w-12 text-right">{brand.score}%</span>
                    <div className="flex items-center w-20">
                      {brand.change > 0 ? (
                        <>
                          <ArrowUpRight className="w-4 h-4 text-[#8BC53F] mr-1" />
                          <span className="text-[#8BC53F] text-sm font-medium">+{brand.change}%</span>
                        </>
                      ) : (
                        <>
                          <ArrowDownRight className="w-4 h-4 text-[#EB008B] mr-1" />
                          <span className="text-[#EB008B] text-sm font-medium">{brand.change}%</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  const renderMentionedBrandsPage = () => (
    <div className="space-y-8">
      {/* Heatmap Visualizations */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Awareness Score by Segment */}
        <Card className="bg-white border-slate-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">Awareness Score by Segment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {heatmapData.segments.map((item, index) => (
                <div key={item.brand} className="flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-700 w-20">{item.brand}</span>
                  <div className="flex-1 mx-3">
                    <div
                      className="h-8 rounded-lg flex items-center justify-center text-white text-sm font-medium transition-all duration-300 hover:scale-105"
                      style={{
                        backgroundColor: `hsl(${200 + (item.score / 100) * 60}, 70%, ${50 + (item.score / 100) * 20}%)`,
                        width: `${Math.max(item.score, 15)}%`,
                      }}
                    >
                      {item.score}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Awareness Score by Funnel Stage */}
        <Card className="bg-white border-slate-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">Awareness Score by Funnel Stage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="grid grid-cols-4 gap-2 text-xs font-medium text-slate-500 mb-2">
                <div>Brand</div>
                <div className="text-center">Top</div>
                <div className="text-center">Middle</div>
                <div className="text-center">Bottom</div>
              </div>
              {heatmapData.funnelStages.map((item) => (
                <div key={item.brand} className="grid grid-cols-4 gap-2 items-center">
                  <span className="text-sm font-medium text-slate-700">{item.brand}</span>
                  <div className="text-center">
                    <div
                      className="h-6 rounded text-white text-xs flex items-center justify-center font-medium"
                      style={{
                        backgroundColor: `hsl(${200 + (item.top / 100) * 60}, 70%, ${50 + (item.top / 100) * 20}%)`,
                      }}
                    >
                      {item.top}%
                    </div>
                  </div>
                  <div className="text-center">
                    <div
                      className="h-6 rounded text-white text-xs flex items-center justify-center font-medium"
                      style={{
                        backgroundColor: `hsl(${200 + (item.middle / 100) * 60}, 70%, ${50 + (item.middle / 100) * 20}%)`,
                      }}
                    >
                      {item.middle}%
                    </div>
                  </div>
                  <div className="text-center">
                    <div
                      className="h-6 rounded text-white text-xs flex items-center justify-center font-medium"
                      style={{
                        backgroundColor: `hsl(${200 + (item.bottom / 100) * 60}, 70%, ${50 + (item.bottom / 100) * 20}%)`,
                      }}
                    >
                      {item.bottom}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Awareness Score by AI Platform */}
        <Card className="bg-white border-slate-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">Awareness Score by AI Platform</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="grid grid-cols-4 gap-2 text-xs font-medium text-slate-500 mb-2">
                <div>Brand</div>
                <div className="text-center">Gemini</div>
                <div className="text-center">OpenAI</div>
                <div className="text-center">Perplexity</div>
              </div>
              {heatmapData.funnelStages.slice(0, 7).map((item) => (
                <div key={item.brand} className="grid grid-cols-4 gap-2 items-center">
                  <span className="text-sm font-medium text-slate-700">{item.brand}</span>
                  <div className="text-center">
                    <div
                      className="h-6 rounded text-white text-xs flex items-center justify-center font-medium"
                      style={{
                        backgroundColor: `hsl(${200 + (item.top / 100) * 60}, 70%, ${50 + (item.top / 100) * 20}%)`,
                      }}
                    >
                      {Math.floor(item.top * 0.6)}%
                    </div>
                  </div>
                  <div className="text-center">
                    <div
                      className="h-6 rounded text-white text-xs flex items-center justify-center font-medium"
                      style={{
                        backgroundColor: `hsl(${200 + (item.middle / 100) * 60}, 70%, ${50 + (item.middle / 100) * 20}%)`,
                      }}
                    >
                      {Math.floor(item.middle * 0.8)}%
                    </div>
                  </div>
                  <div className="text-center">
                    <div
                      className="h-6 rounded text-white text-xs flex items-center justify-center font-medium"
                      style={{
                        backgroundColor: `hsl(${200 + (item.bottom / 100) * 60}, 70%, ${50 + (item.bottom / 100) * 20}%)`,
                      }}
                    >
                      {Math.floor(item.bottom * 0.4)}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Data Table */}
      <Card className="bg-white border-slate-200 shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-slate-900">Brand Performance Details</CardTitle>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-3 px-4 font-semibold text-slate-900">Brand</th>
                  <th className="text-center py-3 px-4 font-semibold text-slate-900">Mentions</th>
                  <th className="text-center py-3 px-4 font-semibold text-slate-900">Last Mentioned</th>
                  <th className="text-center py-3 px-4 font-semibold text-slate-900">Funnel Stages</th>
                  <th className="text-center py-3 px-4 font-semibold text-slate-900">Segments</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                  <td className="py-4 px-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span className="font-medium text-slate-900">Ford</span>
                    </div>
                  </td>
                  <td className="text-center py-4 px-4 font-medium">16</td>
                  <td className="text-center py-4 px-4 text-slate-600">July 29, 2025</td>
                  <td className="text-center py-4 px-4">
                    <div className="flex justify-center space-x-1">
                      <Badge className="bg-[#2D4964] text-white">Bottom</Badge>
                      <Badge className="bg-[#EB008B] text-white">Middle</Badge>
                      <Badge className="bg-[#318E99] text-white">Top</Badge>
                    </div>
                  </td>
                  <td className="text-center py-4 px-4">
                    <Badge variant="secondary">Adventure</Badge>
                  </td>
                </tr>
                <tr className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                  <td className="py-4 px-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span className="font-medium text-slate-900">Toyota</span>
                    </div>
                  </td>
                  <td className="text-center py-4 px-4 font-medium">16</td>
                  <td className="text-center py-4 px-4 text-slate-600">July 29, 2025</td>
                  <td className="text-center py-4 px-4">
                    <div className="flex justify-center space-x-1">
                      <Badge className="bg-[#2D4964] text-white">Bottom</Badge>
                      <Badge className="bg-[#EB008B] text-white">Middle</Badge>
                      <Badge className="bg-[#318E99] text-white">Top</Badge>
                    </div>
                  </td>
                  <td className="text-center py-4 px-4">
                    <Badge variant="secondary">Family</Badge>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderPromptLibraryPage = () => (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Tabs defaultValue="active" className="w-auto">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="active" className="data-[state=active]:bg-[#318E99] data-[state=active]:text-white">
                ACTIVE
              </TabsTrigger>
              <TabsTrigger value="archived">ARCHIVED</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        <div className="flex items-center space-x-3">
          <Button className="bg-[#318E99] hover:bg-[#318E99]/90 text-white">
            <Sparkles className="w-4 h-4 mr-2" />
            Generate Prompts
          </Button>
          <Button variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Add Prompt
          </Button>
        </div>
      </div>

      {/* Search and Filters */}
      <Card className="bg-white border-slate-200 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
              <Input placeholder="Search prompts..." className="pl-10" />
            </div>
            <Select defaultValue="all-segments">
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-segments">All Segments</SelectItem>
                <SelectItem value="adventure">Adventure</SelectItem>
                <SelectItem value="family">Family</SelectItem>
                <SelectItem value="utility">Utility</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="all-stages">
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-stages">All Stages</SelectItem>
                <SelectItem value="top">Top</SelectItem>
                <SelectItem value="middle">Middle</SelectItem>
                <SelectItem value="bottom">Bottom</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Prompts Table */}
      <Card className="bg-white border-slate-200 shadow-sm">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#2D4964] text-white">
                <tr>
                  <th className="text-left py-4 px-4 font-semibold">
                    <Checkbox className="border-white data-[state=checked]:bg-white data-[state=checked]:text-[#2D4964]" />
                  </th>
                  <th className="text-left py-4 px-4 font-semibold">Prompt</th>
                  <th className="text-center py-4 px-4 font-semibold">Brand Mention %</th>
                  <th className="text-center py-4 px-4 font-semibold">Segment</th>
                  <th className="text-center py-4 px-4 font-semibold">Funnel Stage</th>
                  <th className="text-center py-4 px-4 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {prompts.map((prompt, index) => (
                  <tr
                    key={prompt.id}
                    className={`border-b border-slate-100 hover:bg-slate-50 transition-colors ${
                      index % 2 === 0 ? "bg-white" : "bg-slate-50/50"
                    }`}
                  >
                    <td className="py-4 px-4">
                      <Checkbox />
                    </td>
                    <td className="py-4 px-4 max-w-md">
                      <p className="text-slate-900 font-medium truncate">{prompt.text}</p>
                    </td>
                    <td className="text-center py-4 px-4">
                      <div className="flex items-center justify-center">
                        <div className="w-24 mr-3">
                          <Progress value={prompt.brandMention} className="h-2" />
                        </div>
                        <span className="font-semibold text-slate-900">{prompt.brandMention}%</span>
                      </div>
                    </td>
                    <td className="text-center py-4 px-4">
                      <Badge variant="secondary" className="bg-slate-100 text-slate-700">
                        {prompt.segment}
                      </Badge>
                    </td>
                    <td className="text-center py-4 px-4">
                      <Badge
                        className={
                          prompt.funnelStage === "Top"
                            ? "bg-[#318E99] text-white"
                            : prompt.funnelStage === "Middle"
                              ? "bg-[#EB008B] text-white"
                              : "bg-[#2D4964] text-white"
                        }
                      >
                        {prompt.funnelStage}
                      </Badge>
                    </td>
                    <td className="text-center py-4 px-4">
                      <div className="flex items-center justify-center space-x-2">
                        <Button variant="ghost" size="sm" className="text-[#318E99] hover:text-[#318E99]/80">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-slate-600 hover:text-slate-800">
                          <BarChart3 className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-[#EB008B] hover:text-[#EB008B]/80">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-600">Showing 1-9 of 9 prompts</p>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-slate-600">Rows per page:</span>
          <Select defaultValue="100">
            <SelectTrigger className="w-20">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="50">50</SelectItem>
              <SelectItem value="100">100</SelectItem>
              <SelectItem value="200">200</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  )

  const renderCitedSourcesPage = () => (
    <div className="space-y-8">
      {/* Top Section with Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Citations Distribution */}
        <Card className="bg-white border-slate-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">Citations Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center mb-4">
              <div className="relative w-40 h-40">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="35" stroke="#e2e8f0" strokeWidth="10" fill="none" />
                  <circle
                    cx="50"
                    cy="50"
                    r="35"
                    stroke="#318E99"
                    strokeWidth="10"
                    fill="none"
                    strokeDasharray="70 220"
                    strokeLinecap="round"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="35"
                    stroke="#EB008B"
                    strokeWidth="10"
                    fill="none"
                    strokeDasharray="50 220"
                    strokeDashoffset="-70"
                    strokeLinecap="round"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="35"
                    stroke="#2D4964"
                    strokeWidth="10"
                    fill="none"
                    strokeDasharray="100 220"
                    strokeDashoffset="-120"
                    strokeLinecap="round"
                  />
                </svg>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-[#2D4964] rounded-full"></div>
                  <span className="text-sm text-slate-600">Untagged</span>
                </div>
                <span className="text-sm font-medium">45%</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-[#318E99] rounded-full"></div>
                  <span className="text-sm text-slate-600">Earned/Independent</span>
                </div>
                <span className="text-sm font-medium">32%</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-[#EB008B] rounded-full"></div>
                  <span className="text-sm text-slate-600">Owned</span>
                </div>
                <span className="text-sm font-medium">23%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Top Cited Domains */}
        <Card className="bg-white border-slate-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-900">Top Cited Domains</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topDomains.map((domain, index) => (
                <div key={domain.domain} className="flex items-center space-x-3">
                  <div className="w-full">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-slate-900">{domain.domain}</span>
                      <span className="text-sm font-semibold text-slate-700">{domain.percentage}%</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-[#318E99] to-[#8BC53F] h-2 rounded-full transition-all duration-500"
                        style={{ width: `${domain.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Biggest Increase Domains */}
        <Card className="bg-white border-slate-200 shadow-sm">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <CardTitle className="text-lg font-semibold text-slate-900">Biggest Increase Domains</CardTitle>
              <Info className="w-4 h-4 text-slate-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { domain: "kbb.com", percentage: 28, change: 23 },
                { domain: "edmunds.com", percentage: 32, change: 22 },
                { domain: "truecar.com", percentage: 32, change: 16 },
                { domain: "vertexaisearch.cloud.google.com", percentage: 16, change: 11 },
                { domain: "reddit.com", percentage: 16, change: 11 },
              ].map((item) => (
                <div key={item.domain} className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-slate-900 text-sm truncate">{item.domain}</div>
                  </div>
                  <div className="flex items-center space-x-3 ml-4">
                    <span className="font-semibold text-slate-900 text-sm">{item.percentage}%</span>
                    <div className="flex items-center">
                      <TrendingUp className="w-4 h-4 text-[#8BC53F] mr-1" />
                      <span className="text-[#8BC53F] text-sm font-medium">+{item.change}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sources Table */}
      <Card className="bg-white border-slate-200 shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <CardTitle className="text-lg font-semibold text-slate-900">Cited Sources</CardTitle>
              <Tabs defaultValue="pages" className="w-auto">
                <TabsList>
                  <TabsTrigger
                    value="pages"
                    className="data-[state=active]:bg-[#318E99] data-[state=active]:text-white"
                  >
                    PAGES
                  </TabsTrigger>
                  <TabsTrigger value="domains">DOMAINS</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#2D4964] text-white">
                <tr>
                  <th className="text-left py-4 px-4 font-semibold">
                    <Checkbox className="border-white data-[state=checked]:bg-white data-[state=checked]:text-[#2D4964]" />
                  </th>
                  <th className="text-left py-4 px-4 font-semibold">URL</th>
                  <th className="text-center py-4 px-4 font-semibold">Citations</th>
                  <th className="text-center py-4 px-4 font-semibold">Last Cited</th>
                  <th className="text-center py-4 px-4 font-semibold">Category</th>
                  <th className="text-center py-4 px-4 font-semibold">Rules</th>
                </tr>
              </thead>
              <tbody>
                {citedSources.map((source, index) => (
                  <tr
                    key={index}
                    className={`border-b border-slate-100 hover:bg-slate-50 transition-colors ${
                      index % 2 === 0 ? "bg-white" : "bg-slate-50/50"
                    }`}
                  >
                    <td className="py-4 px-4">
                      <Checkbox />
                    </td>
                    <td className="py-4 px-4 max-w-md">
                      <div className="flex items-center space-x-2">
                        <ExternalLink className="w-4 h-4 text-slate-400 flex-shrink-0" />
                        <a
                          href={source.url}
                          className="text-[#318E99] hover:text-[#318E99]/80 font-medium truncate"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {source.url}
                        </a>
                      </div>
                    </td>
                    <td className="text-center py-4 px-4 font-semibold">{source.citations}</td>
                    <td className="text-center py-4 px-4 text-slate-600">{source.lastCited}</td>
                    <td className="text-center py-4 px-4">
                      <Badge variant="secondary">{source.category}</Badge>
                    </td>
                    <td className="text-center py-4 px-4">
                      <Button size="sm" className="bg-[#318E99] hover:bg-[#318E99]/90 text-white">
                        <Plus className="w-4 h-4 mr-1" />
                        Add
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderBrandsPage = () => (
    <div className="space-y-6">
      {/* View Toggle */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-900">Brands</h1>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" className="bg-slate-100">
            <div className="grid grid-cols-2 gap-1 w-4 h-4">
              <div className="bg-slate-600 rounded-sm"></div>
              <div className="bg-slate-600 rounded-sm"></div>
              <div className="bg-slate-600 rounded-sm"></div>
              <div className="bg-slate-600 rounded-sm"></div>
            </div>
          </Button>
          <Button variant="outline" size="sm">
            <div className="flex flex-col space-y-1 w-4 h-4">
              <div className="bg-slate-400 h-0.5 rounded"></div>
              <div className="bg-slate-400 h-0.5 rounded"></div>
              <div className="bg-slate-400 h-0.5 rounded"></div>
            </div>
          </Button>
        </div>
      </div>

      {/* Brands Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {brands.map((brand) => (
          <Card
            key={brand.name}
            className="bg-white border-slate-200 shadow-sm hover:shadow-md transition-all duration-200 group"
          >
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-12 h-12 ${brand.color} rounded-xl flex items-center justify-center text-white font-bold text-lg`}
                  >
                    {brand.logo}
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 text-lg">{brand.name}</h3>
                  </div>
                </div>
                <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="ghost" size="sm">
                    <BarChart3 className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Settings className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-2 mb-1">
                    <div
                      className={`w-6 h-6 ${brand.color} rounded-full flex items-center justify-center text-white font-bold text-sm`}
                    >
                      {brand.prompts}
                    </div>
                  </div>
                  <p className="text-xs text-slate-600">Prompts</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-2 mb-1">
                    <div className="w-6 h-6 bg-[#EB008B] rounded-full flex items-center justify-center text-white font-bold text-sm">
                      {brand.competitors}
                    </div>
                  </div>
                  <p className="text-xs text-slate-600">Competitors</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-2 mb-1">
                    <div className="w-6 h-6 bg-[#EB008B] rounded-full flex items-center justify-center text-white font-bold text-sm">
                      {brand.audits}
                    </div>
                  </div>
                  <p className="text-xs text-slate-600">Audits</p>
                </div>
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                <span className="text-sm font-medium text-slate-700">Daily Prompt Runs</span>
                <Switch checked={brand.dailyRuns} className="data-[state=checked]:bg-[#8BC53F]" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-[#8BC53F] to-[#64EC29] rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">B</span>
                </div>
                <span className="text-xl font-bold text-slate-800">Brandi</span>
              </div>
              <div className="text-slate-400">|</div>
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="bg-[#FAF06C] text-slate-800 hover:bg-[#FAF06C]/80">
                  Misc
                </Badge>
                <span className="text-slate-400">/</span>
                <Badge variant="secondary" className="bg-slate-100 text-slate-700">
                  Jeep
                </Badge>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <span className="text-sm text-slate-600">Welcome, Mob</span>
              <div className="w-8 h-8 bg-[#8BC53F] rounded-full flex items-center justify-center">
                <span className="text-white font-medium text-sm">M</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white border-r border-slate-200 min-h-screen sticky top-16">
          <div className="p-6">
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">Prompt Hub</h3>
                <nav className="space-y-1">
                  {navigation.slice(0, 3).map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setCurrentPage(item.id)}
                      className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                        currentPage === item.id ? "text-white bg-[#EB008B]" : "text-slate-700 hover:bg-slate-100"
                      }`}
                    >
                      <item.icon className="w-4 h-4 mr-3" />
                      {item.name}
                    </button>
                  ))}
                  <button
                    onClick={() => setCurrentPage("cited-sources")}
                    className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                      currentPage === "cited-sources" ? "text-white bg-[#EB008B]" : "text-slate-700 hover:bg-slate-100"
                    }`}
                  >
                    <Link className="w-4 h-4 mr-3" />
                    Cited Sources
                  </button>
                  <button
                    onClick={() => setCurrentPage("mentioned-brands")}
                    className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                      currentPage === "mentioned-brands"
                        ? "text-white bg-[#EB008B]"
                        : "text-slate-700 hover:bg-slate-100"
                    }`}
                  >
                    <Target className="w-4 h-4 mr-3" />
                    Mentioned Brands
                  </button>
                </nav>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">AEO Intel</h3>
                <nav className="space-y-1">
                  <a
                    href="#"
                    className="flex items-center px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg"
                  >
                    <PieChart className="w-4 h-4 mr-3" />
                    AEO Kickstart
                  </a>
                  <a
                    href="#"
                    className="flex items-center px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg relative"
                  >
                    <Users className="w-4 h-4 mr-3" />
                    AEO Health
                    <Badge className="ml-auto bg-[#2D4964] text-white text-xs">next</Badge>
                  </a>
                </nav>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">Brand Settings</h3>
                <nav className="space-y-1">
                  <button
                    onClick={() => setCurrentPage("brands")}
                    className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                      currentPage === "brands" ? "text-white bg-[#EB008B]" : "text-slate-700 hover:bg-slate-100"
                    }`}
                  >
                    <Users className="w-4 h-4 mr-3" />
                    Brands
                  </button>
                </nav>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          <div className="max-w-7xl mx-auto">
            {/* Page Header */}
            <div className="mb-8">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-slate-900 capitalize">
                    {currentPage === "mentioned-brands"
                      ? "Mentioned Brands"
                      : currentPage === "prompt-library"
                        ? "Prompt Library"
                        : currentPage === "cited-sources"
                          ? "Cited Sources"
                          : currentPage === "brands"
                            ? "Brands"
                            : "Performance Summary"}
                  </h1>
                  <p className="text-slate-600 mt-1">
                    {currentPage === "performance" && "Track your brand awareness and share of voice metrics"}
                    {currentPage === "mentioned-brands" &&
                      "Analyze brand mentions across different segments and platforms"}
                    {currentPage === "prompt-library" &&
                      "Manage and optimize your AI prompts for better brand visibility"}
                    {currentPage === "cited-sources" &&
                      "Monitor and analyze your content citations and domain authority"}
                    {currentPage === "brands" && "Manage your brand portfolio and settings"}
                  </p>
                </div>
                <div className="flex items-center space-x-3">
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                  <Button variant="outline" size="sm">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Refresh
                  </Button>
                </div>
              </div>
            </div>

            {/* Filters - Show only for relevant pages */}
            {(currentPage === "performance" ||
              currentPage === "mentioned-brands" ||
              currentPage === "cited-sources") && (
              <div className="flex items-center space-x-4 mb-8 p-4 bg-white rounded-xl border border-slate-200 shadow-sm">
                <Filter className="w-5 h-5 text-slate-400" />
                <div className="flex items-center space-x-4">
                  <div>
                    <label className="text-sm font-medium text-slate-700 mb-1 block">Funnel Stage</label>
                    <Select defaultValue="all">
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All</SelectItem>
                        <SelectItem value="top">Top</SelectItem>
                        <SelectItem value="middle">Middle</SelectItem>
                        <SelectItem value="bottom">Bottom</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-slate-700 mb-1 block">Segment</label>
                    <Select defaultValue="all">
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All</SelectItem>
                        <SelectItem value="segment1">Adventure</SelectItem>
                        <SelectItem value="segment2">Family</SelectItem>
                        <SelectItem value="segment3">Utility</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-slate-700 mb-1 block">Date Range</label>
                    <Select value={dateRange} onValueChange={setDateRange}>
                      <SelectTrigger className="w-36">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="7days">Last 7 Days</SelectItem>
                        <SelectItem value="30days">Last 30 Days</SelectItem>
                        <SelectItem value="90days">Last 90 Days</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* Page Content */}
            {currentPage === "performance" && renderPerformancePage()}
            {currentPage === "mentioned-brands" && renderMentionedBrandsPage()}
            {currentPage === "prompt-library" && renderPromptLibraryPage()}
            {currentPage === "cited-sources" && renderCitedSourcesPage()}
            {currentPage === "brands" && renderBrandsPage()}
          </div>
        </div>
      </div>
    </div>
  )
}
